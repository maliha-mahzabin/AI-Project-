#include<iostream>
#include<stdlib.h>
using namespace std;


char array[3][3] = { {'1','2','3'},{'4','5','6'},{'7','8','9'} };
char turn = 'X';
int row, column;
bool draw = false;
void display_array() {
    system("cls");
    cout << endl;
    cout << "\t\tT I C   T A C   T O E" << endl;
    cout << endl;
    cout << "\tPLAYER1[X]\n \tPLAYER2[O]" << endl;
    cout << endl;
    cout << "\t\t     |     |     " << endl;
    cout << "\t\t  " << array[0][0] << "  |  " << array[0][1] << "  |  " << array[0][2] << endl;
    cout << "\t\t_____|_____|_____" << endl;
    cout << "\t\t     |     |     " << endl;
    cout << "\t\t  " << array[1][0] << "  |  " << array[1][1] << "  |  " << array[1][2] << endl;
    cout << "\t\t_____|_____|_____" << endl;
    cout << "\t\t     |     |     " << endl;
    cout << "\t\t  " << array[2][0] << "  |  " << array[2][1] << "  |  " << array[2][2] << endl;
    cout << "\t\t     |     |     " << endl;
    cout << endl;

}
void PLAYER_turn() {
    int choise;

    if (turn == 'X') {
        cout << "\tPLAYER 1[X] TURN :";
        cin >> choise;
    }
    if (turn == 'O') {
        cout << "\tPLAYER 2[O] TURN :";
        cin >> choise;
    }
    switch (choise)
    {
    case 1: row = 0; column = 0; break;
    case 2: row = 0; column = 1; break;
    case 3: row = 0; column = 2; break;
    case 4: row = 1; column = 0; break;
    case 5: row = 1; column = 1; break;
    case 6: row = 1; column = 2; break;
    case 7: row = 2; column = 0; break;
    case 8: row = 2; column = 1; break;
    case 9: row = 2; column = 2; break;
    default:
        cout << "INVALID CHOICE!!" << endl;
        break;
    }
    if (turn == 'X' && array[row][column] != 'X' && array[row][column] != 'O') {
        array[row][column] = 'X';
        turn = 'O';
    }
    else if (turn == 'O' && array[row][column] != 'X' && array[row][column] != 'O') {
        array[row][column] = 'O';
        turn = 'X';
    }
    else {
        cout << "BOX HAS BEEN ALREADY FILLED...!!\n  PLEASE TRY AGAIN" << endl;
        PLAYER_turn();
    }
    display_array();
}

bool Gameover() {

    for (int i = 0; i < 3; i++) {
        if (array[i][0] == array[i][1] && array[i][0] == array[i][2] || array[0][i] == array[1][i] && array[0][i] == array[2][i])
        return false;
    }
    if (array[0][0] == array[1][1] && array[0][0] == array[2][2] || array[0][2] == array[1][1] && array[0][2] == array[2][0]) {
        return false;
    }


    for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
        if (array[i][j] != 'X' && array[i][j] != 'O') {
            return true;
        }

    draw = true;
    return false;
}

int main() {
    while (Gameover()) {
        display_array();
        PLAYER_turn();
        Gameover();

    }
    if (turn == 'X' && draw == false) {
        cout << "PLAYER 2[O] HAS WON!!!" << endl;
    }
    else if (turn == 'O'  && draw == false) {
        cout << "PLAYER 1[X] HAS WON!!!" << endl;
    }
    else {
        cout << "GAME DRAW!!" << endl;
    }


}
